<?php
  include 'baza1.php';
?>
<?php
  include 'polaczenie.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>WHERETOWATCH</title>
</head>
<body>
    
    <div>
        <ul>
            
            <li><a href="../projekt/login.php">Zaloguj sie</a></li>
            <li><a href="#about">About</a></li>
            <a href="strona.php">
            <img class="logo" src="LOGOPN.png" alt="logo">
            </a>
          </ul>
          

    </div>
    <h1 class="h2sz">Wyszukaj</h1>
    <div class="wrapper">
    <form action="search.php" method="POST">
    <input type="text" name="search" placeholder="search" class="szukarka">
    <button type="submit" name="submit" class="szukarka2">Search</button>
</form>
    </div>
</body>
</html>