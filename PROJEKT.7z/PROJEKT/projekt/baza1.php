<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "filmy";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{
	die("zjebało się");
}
?>