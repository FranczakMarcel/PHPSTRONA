<link rel="stylesheet" href="style.css">
<div>
        <ul>
            
            <li><a href="../projekt/login.php">Zaloguj sie</a></li>
            <li><a href="#about">About</a></li>
            <a href="strona.php">
            <img class="logo" src="LOGOPN.png" alt="logo">
            </a>
          </ul>
          

    </div>

<?php 
session_start();

include("polaczenie.php");

if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$nazwa = $_POST['nazwa'];
		$password = $_POST['password'];

		if(!empty($nazwa) && !empty($password) && !is_numeric($nazwa))
		{
			$query = "SELECT * FROM uzytkownicy WHERE nazwa = '$nazwa' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$data = mysqli_fetch_assoc($result);
					
					if($data['password'] === $password)
					{

						$_SESSION['user_id'] = $data['user_id'];
						header("Location: strona.php");
						die;
					}
				}
			}	
			echo "<h1> Zła nazwa lub hasło </h1>";
		}else
		{
			echo "E ale napisz coś w obu lukach";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<div style="flex-grow: 1; text-align:center">
    <h1 class="h2sz">Zaloguj się</h1>
    <form method="post">
    <label for="nazwa">Login:</label>
    <input type="text" name="nazwa" id="nazwa">
    <label for="password">Hasło:</label>
    <input type="password" name="password" id="password">
    <input type="submit" value="Zaloguj">
    <p>Nie masz konta? <a href="rejestracja.php">Załóż je już teraz!</a></p>
    </form>
</div>