<?php
  include 'baza1.php';
?>


<link rel="stylesheet" href="style.css">

<div>
        <ul>
            
            <li><a href="../projekt/login.php">Zaloguj sie</a></li>
            <li><a href="#about">About</a></li>
            <a href="strona.php">
            <img class="logo" src="LOGOPN.png" alt="logo">
            </a>
          </ul>
          

    </div>
<h1 class="h2sz">Wyniki</h1>

<div class="wyniki">
<?php
if (isset($_POST['submit'])) {
    $search = mysqli_real_escape_string($con, $_POST['search']);
    $quarry = "SELECT * FROM film WHERE f_title LIKE '%$search%' OR f_text LIKE '%$search%' OR f_director LIKE '%$search%' OR f_date LIKE '%$search%'";
    $result = mysqli_query($con, $quarry);
    $queryResult = mysqli_num_rows($result);

    echo" Wyszukano ".$queryResult." tyle wyników.";
    if ($queryResult > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>
            <h3>".$row['f_title']."</h3>
            <p>".$row['f_text']."</p>
            <p>".$row['f_director']."</p>
            <p>".$row['f_date']."</p>
            <p>".$row['f_link']."</p>
            </div>";
        }

    } else {
        echo "Przepraszamy nie mamy jescze tego w naszej bazie!";
    }

}
?>
</div>


