<link rel="stylesheet" href="style.css">
<div>
        <ul>
            
            <li><a href="../projekt/login.php">Zaloguj sie</a></li>
            <li><a href="#about">About</a></li>
            <a href="strona.php">
            <img class="logo" src="LOGOPN.png" alt="logo">
            </a>
          </ul>
          

    </div>
<?php
if(isset($_REQUEST['nazwa']) && isset($_REQUEST['password'])) {
    $db = new mysqli("localhost", "root", "", "projekt");
    $q = $db->prepare("INSERT INTO uzytkownicy VALUES (NULL, ?, ?)");
    $q->bind_param("ss",$_REQUEST['nazwa'],$_REQUEST['password']);

    if($q->execute()) {
        header ('Location: login.php');
    }
}else{
    echo'<div style="flex-grow: 1; text-align:center">
    <h1 class="h2sz">Zarejestruj się</h1>
    <form action="rejestracja.php" method="post">
    <label for="nazwa">Login:</label>
    <input type="text" name="nazwa" id="nazwa">
    <label for="password">Hasło:</label>
    <input type="password" name="password" id="password">
    <input type="submit" value="Zarejestruj">
    <p>Masz już konto? <a href="login.php">Zaloguj się!</a></p>
    </form>
</div>
    ';
}
?>